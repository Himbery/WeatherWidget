package com.mast8.weatherwid;

public class Main {
    public int humidity;
    public int pressure;
    public double temp;
}
