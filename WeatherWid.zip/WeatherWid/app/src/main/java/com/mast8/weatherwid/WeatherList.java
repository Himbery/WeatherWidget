package com.mast8.weatherwid;

import java.util.ArrayList;

public class WeatherList {
    public ArrayList<Weather> weather = new ArrayList<Weather>();
    public Main main;

}
