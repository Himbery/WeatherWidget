package com.mast8.weatherwid;

public class Weather {
    public String description;
    public String main;
    public String icon;
}
